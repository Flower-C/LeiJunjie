create view view_employ as
  select `e`.`id` AS `id`, `e`.`name` AS `name`, `e`.`email` AS `email`, `d`.`departmentname` AS `department`
  from (`flowerc`.`employee` `e` left join `flowerc`.`department` `d` on ((`e`.`departmentid` = `d`.`id`)));

